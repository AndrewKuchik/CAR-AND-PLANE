using UnityEngine;

public class NewMonoBehaviourScript : MonoBehaviour

{
    public float speed = 20;
    public float turnSpeed = 5;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        HorizontalInput
        //gribu bīdīt mašīnu
        transform.Translate(Vector3.back * speed * Time.deltaTime);
        transform.Translate(Vector3.right * Time.deltaTime * turnSpeed);
    }
}
